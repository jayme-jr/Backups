+++
# Custom widget.
# An example of using the custom widget to create your own homepage section.
# To create more sections, duplicate this file and edit the values below as desired.
widget = "custom"
active = true
date = "2016-04-20T00:00:00"

# Note: a full width section format can be enabled by commenting out the `title` and `subtitle` with a `#`.
title = "Teaching"
subtitle = ""

# Order that this section will appear in.
weight = 60

+++

This is an example of using the *custom* widget to create your own homepage section.

I am a teaching instructor for the following courses at University X:

- CS101: An intro to computer science
- CS102: An intro to computer science
- CS103: An intro to computer science
- CS104: An intro to computer science
- CS105: An intro to computer science
- CS106: An intro to computer science
- CS107: An intro to computer science
