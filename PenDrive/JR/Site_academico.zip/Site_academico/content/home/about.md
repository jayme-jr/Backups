+++
# About/Biography widget.
widget = "about"
active = true
date = 2016-04-20T00:00:00

# Order that this section will appear in.
weight = 5

# List your academic interests.
[interests]
  interests = [
    "Estatística Computacional",
    "Data Science",
    "Documentos Dinâmicos",
    "Text Mining"
  ]

# List your qualifications (such as academic degrees).
[[education.courses]]
  course = "Graduando em Estatística"
  institution = "UFPR"
  year = 2016

[[education.courses]]
  course = "Bacharelado em Sistemas de Informação - Incompleto"
  institution = "SPEI"
  year = 2013 
  
+++

# Biografia

Sou estudante do curso de Estatística pela [Universidade Federal do Parana][1]
e integrante do Pet Estatística desde 2016. Tenho interesse de longa data
na área computacional e atualmente nas ferramentas utilizadas na estatística.



[1]: http://www.ufpr.br/portalufpr/
